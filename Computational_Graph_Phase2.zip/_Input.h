#pragma once
void inputNode();
void inputOperate();
void inputEvalNum(int answer_num);
void delete_memory();
